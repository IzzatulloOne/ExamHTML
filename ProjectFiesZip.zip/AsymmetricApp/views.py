from django.shortcuts import render

def about_us(request):
    return render(request, 'page-asymmetric-agency-about-us.html')

def case_studies(request):
    return render(request, 'page-asymmetric-agency-case-studies.html')

def expertise(request):
    return render(request, 'page-asymmetric-agency-expertise.html')

def our_approach(request):
    return render(request, 'page-asymmetric-agency-our-approach.html')

def page_404(request, exception=None):
    return render(request, 'page-404.html', status=404)