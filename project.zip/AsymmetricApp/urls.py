from django.urls import path
from . import views

urlpatterns = [
    path('', views.about_us, name='about_us'),
    path('case_studies/', views.case_studies, name='studies'),
    path('expertise/', views.expertise, name='expertise'),
    path('our_approach', views.our_approach, name='our_approach'),
    path('notfound404/', views.page_404, name='404'),
]