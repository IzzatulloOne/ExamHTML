from django.db import models

# Create your models here.
class DigitalProducts(models.Model):
    ...


class DesignersAndDevelopers(models.Model):
    ...


class Clients(models.Model):
    ...


class AboutMe(models.Model):
    ...

